const locale = {
  APPLICATIONS: "BOOKINGS",
  DASHBOARDS: "INBOX",
  CALENDAR: "Calendar",
  ECOMMERCE: "Services",
  ACADEMY: "Academy",
  MAIL: "Mail",
  TASKS: "Tasks",
  FILE_MANAGER: "File Manager",
  CONTACTS: "Customers",
  CHAT: "Chat",
  SCRUMBOARD: "Scrumboard",
  NOTES: "Notes",
  USER: "Users",
  USERS: "Users",
};

export default locale;
