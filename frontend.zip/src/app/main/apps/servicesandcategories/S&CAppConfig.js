import { lazy } from "react";
import { Navigate } from "react-router-dom";

const Product = lazy(() => import("./service/Service"));
const Products = lazy(() => import("./services/Services"));
const Order = lazy(() => import("./category/Categories"));
const Orders = lazy(() => import("./categories/Category"));

const ServicesandCategoriesConfig = {
  settings: {
    layout: {},
  },
  routes: [
    {
      path: "apps/services/",
      element: <Products />,
    },
    {
      path: "apps/services/:productId/*",
      element: <Product />,
    },
    {
      path: "apps/categories",
      element: <Orders />,
    },
    {
      path: "apps/categories/:productId/*",
      element: <Order />,
    },
  ],
};

export default ServicesandCategoriesConfig;
