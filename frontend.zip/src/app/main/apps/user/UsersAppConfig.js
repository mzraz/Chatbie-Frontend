import { lazy } from "react";
import ContactView from "./contact/UserView";
import ContactForm from "./contact/UserForm";

const ContactsApp = lazy(() => import("./UsersApp"));

const ContactAppConfig = {
  settings: {
    layout: {
      config: {},
    },
  },
  routes: [
    {
      path: "/apps/users",
      element: <ContactsApp />,
      children: [
        {
          path: ":id",
          element: <ContactView />,
        },
        {
          path: ":id/edit",
          element: <ContactForm />,
        },
      ],
    },
  ],
};

export default ContactAppConfig;
