import { lazy } from "react";
import ContactView from "./contact/UserView";
import ContactForm from "./contact/UserForm";

const CustomersApp = lazy(() => import("./UsersApp"));

const CustomerAppConfig = {
  settings: {
    layout: {
      config: {},
    },
  },
  routes: [
    {
      path: "/apps/customers",
      element: <CustomersApp />,
      children: [
        {
          path: ":id",
          element: <ContactView />,
        },
        {
          path: ":id/edit",
          element: <ContactForm />,
        },
      ],
    },
  ],
};

export default CustomerAppConfig;
