import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, useForm } from "react-hook-form";
import FuseUtils from "@fuse/utils/FuseUtils";
import Button from "@mui/material/Button";
import FormControl from "@mui/material/FormControl";
import FormControlLabel from "@mui/material/FormControlLabel";
import InputLabel from "@mui/material/InputLabel";
import Autocomplete from "@mui/material/Autocomplete";
import { DesktopDateTimePicker } from "@mui/x-date-pickers/DesktopDateTimePicker";

import dayjs from "dayjs";
import { FormHelperText } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import * as yup from "yup";
import _ from "@lodash";
import { Popover } from "@mui/material";
import FuseSvgIcon from "@fuse/core/FuseSvgIcon";
import {
  addEvent,
  closeEditEventDialog,
  closeNewEventDialog,
  removeEvent,
  selectEventDialog,
  updateEvent,
} from "../../store/eventsSlice";
import EventLabelSelect from "../../EventLabelSelect";
import EventModel from "../../model/EventModel";
import { selectFirstLabelId } from "../../store/labelsSlice";
import { selectUser } from "app/store/userSlice";
import { setupKey } from "src/configurationKeys";
import { showMessage } from "app/store/fuse/messageSlice";

const defaultValues = EventModel();

const schema = yup.object().shape({
  title: yup.string().required("You must enter a title"),
});
import { getAllTimezones } from "countries-and-timezones";

const time_zone = getAllTimezones();

function EventDialog(props) {
  const dispatch = useDispatch();
  const eventDialog = useSelector(selectEventDialog);
  const firstLabelId = useSelector(selectFirstLabelId);
  const user = useSelector(selectUser);

  const [userAllData, setUserAllData] = useState({});
  const [appointmentBody, setAppointmentBody] = useState({
    provider_id: "",
    service_id: "",
    starting_date: "",
    ending_date: "",
    title: "",
    label: "1a470c8e-40ed-4c2d-b590-a4f1f6ead6cc",
  });
  const [appointmentTime, setAppointmentTime] = useState({
    starting_date: new Date(),
    ending_date: new Date(),
  });
  const [customerBody, setCustomerBody] = useState({
    first_name: "",
    last_name: "",
    phone_number: "",
    email: "",
    city: "",
    zip_code: "",
    notes: "",
    time_zone: "",
    language: "",
    id: "",
  });
  const [customerFormOpen, setCustomerForm] = useState(false);
  const [existingCustomers, setExistingCustomers] = useState([]);

  const customersData = [];

  useEffect(() => {
    async function getAllData() {
      const accessToken = window.localStorage.getItem("jwt_access_token");
      const requestBody = {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      };
      var res = await fetch(
        `${setupKey}${user?.selectedOrganization?.id}/userInformation`,
        requestBody
      ).then((data) => data.json());

      setUserAllData({ ...res });
    }
    getAllData();
  }, []);

  const data = Object.values(time_zone);
  const CustomersDataHandle = () => {
    setExistingCustomers([...userAllData.customers.data]),
      setCustomerForm(false);
  };

  const { reset, formState, watch, control, getValues } = useForm({
    defaultValues,
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const { isValid, dirtyFields, errors } = formState;

  const start = watch("start");
  const end = watch("end");
  const id = watch("id");
  const languages = [
    "English",
    "Arabic",
    "bulgarian",
    "Catalan",
    "Chinese",
    "Czech",
    "Danish",
    "Dutch",
    "finnish",
    "French",
    "German",
    "Greek",
    "Hebrew",
    "Hindi",
    "Hungarian",
    "Italian",
    "Japenese",
    "Marathi",
    "Persian",
    "Polish",
    "Portuguese",
    "Portuguese-br",
    "Romanian",
    "Russian",
    "Slovak",
    "Spanish",
    "Turkish",
  ];

  const initDialog = useCallback(() => {
    if (eventDialog.type === "edit" && eventDialog.data) {
      reset({ ...eventDialog.data });
    }

    if (eventDialog.type === "new") {
      reset({
        ...defaultValues,
        ...eventDialog.data,
        extendedProps: {
          ...defaultValues.extendedProps,
          label: firstLabelId,
        },
        id: FuseUtils.generateGUID(),
      });
    }
  }, [eventDialog.data, eventDialog.type, reset]);

  useEffect(() => {
    if (eventDialog.props.open) {
      initDialog();
    }
  }, [eventDialog.props.open, initDialog]);

  function closeComposeDialog() {
    return eventDialog.type === "edit"
      ? dispatch(closeEditEventDialog())
      : dispatch(closeNewEventDialog());
  }

  /**
   * Form Submit
   */
  function onSubmit(ev) {
    ev.preventDefault();

    const findServiceID = userAllData.services.find(
      (item) => item.name === appointmentBody.service_id
    );
    const findProviderID = userAllData.providers.find(
      (item) => item.user_name === appointmentBody.provider_id
    );

    const appointmentBodys = {
      ...appointmentBody,
      service_id: findServiceID.id,
      provider_id: findProviderID.id,
    };

    const data = {
      appointmentBody: {
        ...appointmentBodys,
      },
      customerBody: {
        ...customerBody,
      },
    };
    // if (eventDialog.type === "new") {
    dispatch(addEvent(data)).then((res) => {
      if (
        !res?.payload?.error &&
        res?.payload !== undefined &&
        !res?.payload?.error
      ) {
        dispatch(
          showMessage({
            message: "User Created successfully.",
            variant: "success",
          })
        );
        navigate("/apps/users/");
      } else {
        dispatch(
          showMessage({
            message: res?.payload?.error,
            variant: "Failed",
          })
        );
      }
    });

    setCustomerBody({
      first_name: "",
      last_name: "",
      phone_number: "",
      email: "",
      city: "",
      zip_code: "",
      notes: "",
      time_zone: "",
      language: "",
      id: "",
    });

    setAppointmentBody({
      provider_id: "",
      service_id: "",
      starting_date: "",
      ending_date: "",
      title: "",
      label: "1a470c8e-40ed-4c2d-b590-a4f1f6ead6cc",
    });
    closeComposeDialog();
  }

  const handleCustomerDataChange = (e) => {
    const data = getValues();
    const { name, value } = e.target;
    setCustomerBody((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleAppointmentDataChange = (e) => {
    const data = getValues();
    const { name, value } = e.target;
    setAppointmentBody((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const selectCustomerData = (e) => {
    const findCustomer = userAllData?.customers?.data?.find(
      (item) => item.email === e.target.value
    );
    setCustomerBody({
      first_name: findCustomer.first_name,
      last_name: findCustomer.last_name,
      phone_number: findCustomer.phone_number,
      email: findCustomer.email,
      city: findCustomer.city,
      zip_code: findCustomer.zip_code,
      notes: findCustomer.notes,
      time_zone: findCustomer.time_zone,
      language: findCustomer.language,
      id: findCustomer.id,
    });

    setCustomerForm(true);
    setExistingCustomers([]);
  };

  const handleDateTimeStartingPoint = (e) => {
    const defaultDate = dayjs(e).format("MM/DD/YYYY hh:mm A");
    setAppointmentBody((prevData) => ({
      ...prevData,
      starting_date: defaultDate,
    }));
  };
  const handleDateTimeEndingPoint = (e) => {
    const defaultDate = dayjs(e).format("MM/DD/YYYY hh:mm A");
    setAppointmentBody((prevData) => ({
      ...prevData,
      ending_date: defaultDate,
    }));
  };
  /**
   * Remove Event
   */
  function handleRemove() {
    dispatch(removeEvent(id));
    closeComposeDialog();
  }

  const customerForm = () => {
    setCustomerForm(true);
    setExistingCustomers([]);
  };
  return (
    <Popover
      {...eventDialog.props}
      anchorReference="anchorPosition"
      anchorOrigin={{
        vertical: "center",
        horizontal: "right",
      }}
      transformOrigin={{
        vertical: "center",
        horizontal: "left",
      }}
      onClose={closeComposeDialog}
      component="form"
    >
      <div className="flex flex-col max-w-full p-24 pt-32 sm:pt-40 sm:p-32 w-auto">
        <div className="flex sm:space-x-24 mb-16">
          <FuseSvgIcon className="hidden sm:inline-flex mt-16" color="action">
            heroicons-outline:pencil-alt
          </FuseSvgIcon>
          <h1>Appointment Details</h1>

          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Service*</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="Service"
              required
              name="service_id"
              value={appointmentBody.service_id}
              onChange={(e) => handleAppointmentDataChange(e)}
            >
              {userAllData?.services?.map((item) => (
                <MenuItem value={item.name}>{item.name}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Provider*</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="Provider"
              required
              value={appointmentBody.provider_id}
              onChange={(e) => handleAppointmentDataChange(e)}
              name="provider_id"
            >
              {userAllData?.providers?.map((item) => (
                <MenuItem value={item.user_name}>{item.user_name}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            id="title"
            label="Title"
            className="flex-auto"
            name="title"
            value={appointmentBody.title}
            onChange={(e) => handleAppointmentDataChange(e)}
            error={!!errors.title}
            helperText={errors?.title?.message}
            variant="outlined"
            autoFocus
            fullWidth
          />
        </div>

        <div className="flex sm:space-x-24 mb-16">
          <FuseSvgIcon className="hidden sm:inline-flex mt-16" color="action">
            heroicons-outline:calendar
          </FuseSvgIcon>
          <div className="w-full">
            <div className="flex flex-column sm:flex-row w-full items-center space-x-16">
              <DesktopDateTimePicker
                name="starting_date"
                value={appointmentTime.starting_date}
                onChange={(e) => handleDateTimeStartingPoint(e)}
              />
              <DesktopDateTimePicker
                value={appointmentTime.ending_date}
                name="ending_date"
                onChange={(e) => handleDateTimeEndingPoint(e)}
              />
            </div>

            {/* <Controller
              name="allDay"
              control={control}
              render={({ field: { onChange, value } }) => (
                <FormControlLabel
                  className="mt-8"
                  label="All Day"
                  control={
                    <Switch
                      onChange={(ev) => {
                        onChange(ev.target.checked);
                      }}
                      checked={value}
                      name="allDay"
                    />
                  }
                />
              )}
            /> */}
          </div>
        </div>

        {/* <div className="flex sm:space-x-24 mb-16">
          <FuseSvgIcon className="hidden sm:inline-flex mt-16" color="action">
            heroicons-outline:menu-alt-2
          </FuseSvgIcon>

          <TextField
            // {...field}
            className="mt-8 mb-16"
            id="desc"
            label="Notes"
            type="text"
            multiline
            rows={5}
            variant="outlined"
            fullWidth
          />

          {/* )}
          /> 
        </div> */}

        <FuseSvgIcon className="hidden sm:inline-flex mt-16" color="action">
          heroicons-outline:pencil-alt
        </FuseSvgIcon>
        <h1>Customer Details</h1>
        <div className="flex flex-row items-center space-x-8">
          <div>
            <div className="" />
            <Button
              variant="contained"
              color="primary"
              onClick={() => customerForm()}
            >
              New
            </Button>
          </div>
          <div className="flex items-center space-x-8">
            <div className="" />
            <Button
              variant="contained"
              color="primary"
              onClick={() => CustomersDataHandle()}
            >
              Select
            </Button>
          </div>
        </div>
        {existingCustomers.length !== 0 ? (
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Customers</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="Customers"
              required
              //  value={selectCustomer}
              onChange={(e) => selectCustomerData(e)}
              name="selectCustomer"
            >
              {userAllData?.customers?.data?.map((item) => (
                <MenuItem value={item.email}>
                  {item.first_name} {item.last_name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        ) : (
          <div></div>
        )}

        {customerFormOpen === true ? (
          <div className="mt-14">
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                // {...field}
                id="title"
                label="First Name"
                className="flex-auto"
                name="first_name"
                onChange={(e) => handleCustomerDataChange(e)}
                value={customerBody.first_name}
                error={!!errors.title}
                helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                required
                fullWidth
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                // {...field}
                id="title"
                label="Last Name"
                name="last_name"
                onChange={(e) => handleCustomerDataChange(e)}
                value={customerBody.last_name}
                className="flex-auto"
                error={!!errors.title}
                helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                fullWidth
                required
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                id="title"
                label="Email"
                name="email"
                className="flex-auto"
                // error={!!errors.title}
                value={customerBody.email}
                onChange={(e) => handleCustomerDataChange(e)}
                // helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                required
                fullWidth
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                // {...field}
                id="title"
                label="Phone Number"
                name="phone_number"
                value={customerBody.phone_number}
                onChange={(e) => handleCustomerDataChange(e)}
                className="flex-auto"
                error={!!errors.title}
                helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                fullWidth
                required
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                // {...field}
                id="title"
                name="address"
                label="Address"
                value={customerBody.address}
                className="flex-auto"
                error={!!errors.title}
                onChange={(e) => handleCustomerDataChange(e)}
                helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                fullWidth
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                // {...field}
                id="title"
                label="City"
                name="city"
                value={customerBody.city}
                className="flex-auto"
                error={!!errors.title}
                onChange={(e) => handleCustomerDataChange(e)}
                helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                fullWidth
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              <FormControl fullWidth>
                <InputLabel id="demo-timezones">Timezones*</InputLabel>
                <Select
                  labelId="demo-timezones-select"
                  id="time_zone"
                  label="Timezones*"
                  value={customerBody.time_zone}
                  // error={!!error.time_zone}
                  // helperText={error.time_zone}
                  name="time_zone"
                  required
                  onChange={(e) => handleCustomerDataChange(e)}
                  // value={adminData.time_zone}
                  MenuProps={{
                    disablePortal: true,
                  }}
                >
                  {data.map((item) => (
                    <MenuItem key={item.name} value={item.name}>
                      {`${item.name} (${item.dstOffsetStr})`}
                    </MenuItem>
                  ))}
                </Select>
                <FormHelperText
                  style={{
                    color: "#e74e3e",
                  }}
                >
                  {/* {error.time_zone} */}
                </FormHelperText>
              </FormControl>
            </div>
            <div className="flex sm:space-x-24 mb-16">
              <FormControl fullWidth>
                <InputLabel id="demo-language">language*</InputLabel>
                <Select
                  labelId="demo-timezones-select"
                  id="language"
                  value={customerBody.language}
                  label="language*"
                  name="language"
                  required
                  onChange={(e) => handleCustomerDataChange(e)}
                  // value={adminData.language}
                >
                  {languages.map((item) => (
                    <MenuItem value={item} key={item}>
                      {item}
                    </MenuItem>
                  ))}
                </Select>
                <FormHelperText
                  style={{
                    color: "#e74e3e",
                  }}
                >
                  {/* {error.language} */}
                </FormHelperText>
              </FormControl>
            </div>
            <div className="flex sm:space-x-24 mb-16">
              {/* <Controller
                name="title"
                control={control}
                render={({ field }) => ( */}
              <TextField
                // {...field}
                id="title"
                name="zip_code"
                label="Zip Code"
                className="flex-auto"
                value={customerBody.zip_code}
                error={!!errors.title}
                onChange={(e) => handleCustomerDataChange(e)}
                helperText={errors?.title?.message}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                autoFocus
                fullWidth
              />
              {/* )}
              /> */}
            </div>
            <div className="flex sm:space-x-24 mb-16">
              <FuseSvgIcon
                className="hidden sm:inline-flex mt-16"
                color="action"
              >
                heroicons-outline:menu-alt-2
              </FuseSvgIcon>

              <TextField
                className="mt-8 mb-16"
                id="desc"
                label="Notes"
                name="notes"
                value={customerBody.notes}
                onChange={(e) => handleCustomerDataChange(e)}
                type="text"
                multiline
                rows={5}
                variant="outlined"
                fullWidth
              />
              {/* )}
              /> */}
            </div>{" "}
          </div>
        ) : (
          <div></div>
        )}
        {}
        {eventDialog.type === "new" ? (
          <div className="flex items-center space-x-8">
            <div className="flex flex-1" />
            <Button variant="contained" color="primary" onClick={onSubmit}>
              Add
            </Button>
          </div>
        ) : (
          <div className="flex items-center space-x-8">
            <div className="flex flex-1" />
            <IconButton onClick={handleRemove} size="large">
              <FuseSvgIcon>heroicons-outline:trash</FuseSvgIcon>
            </IconButton>
            <Button variant="contained" color="primary" onClick={onSubmit}>
              Save
            </Button>
          </div>
        )}
      </div>
    </Popover>
  );
}

export default EventDialog;
