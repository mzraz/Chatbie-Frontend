import {
  createAsyncThunk,
  createEntityAdapter,
  createSelector,
  createSlice,
} from "@reduxjs/toolkit";
import axios from "axios";
import formatISO from "date-fns/formatISO";
import { selectSelectedLabels } from "./labelsSlice";
import { setupKey } from "src/configurationKeys";
import { NetworkCell } from "@mui/icons-material";
export const dateFormat = "YYYY-MM-DDTHH:mm:ss.sssZ";

export const getEvents = createAsyncThunk(
  "calendarApp/events/getEvents",
  async (params, thunkAPI) => {
    const user = thunkAPI.getState().user;
    const accessToken = window.localStorage.getItem("jwt_access_token");
    const requestBody = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    };
    var response = await fetch(
      `${setupKey}${user?.selectedOrganization?.id}/appointments`,
      requestBody
    ).then((data) => data.json());

    const data = response.data;
    const transformedData = data.map((transformItem) => ({
      allDay: false,
      end: transformItem.ending_date,
      extendedProps: {
        desc: "",
        label: transformItem.label, // You can adjust this if needed
      },
      id: transformItem.id,
      start: transformItem.starting_date,
      title: transformItem.title,
    }));

    return transformedData;
    // return [
    //   {
    //     allDay: false,
    //     end: "2023-09-21T00:00:00+03:00",
    //     extendedProps: {
    //       desc: "",
    //       label: "1a470c8e-40ed-4c2d-b590-a4f1f6ead6cc",
    //     },
    //     id: "1",
    //     start: "2023-09-20T00:00:00+03:00",
    //     title: "Long Event",
    //   },
    // ];
  }
);

export const addEvent = createAsyncThunk(
  "calendarApp/events/addEvent",
  async (newEvent, { dispatch }) => {
    console.log(newEvent.customerBody);
    const updatedData = {
      first_name: newEvent.customerBody.first_name,
      last_name: newEvent.customerBody.last_name,
      phone_number: newEvent.customerBody.phone_number,
      email: newEvent.customerBody.email,
      city: newEvent.customerBody.city,
      zip_code: newEvent.customerBody.zip_code,
      notes: newEvent.customerBody.notes,
      time_zone: newEvent.customerBody.time_zone,
      language: newEvent.customerBody.language,
    };
    const data = {
      appointmentBody: {
        ...newEvent.appointmentBody,
      },
      customerBody: {
        ...updatedData,
      },
    };

    const accessToken = window.localStorage.getItem("jwt_access_token");
    const requestBody = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(data),
    };

    var response = await fetch(
      `${setupKey}appointments/${newEvent.customerBody.id}`,
      requestBody
    ).then((data) => data.json());
    if (!response.error) {
      const updatedData = {
        allDay: false,
        end: response.newAppointment.ending_date,
        extendedProps: {
          desc: "",
          label: response.newAppointment.label,
        },
        id: response.newAppointment.id,
        start: response.newAppointment.starting_date,
        title: response.newAppointment.title,
      };

      const data = updatedData;

      return data;
    } else {
      return response;
    }
  }
);

export const updateEvent = createAsyncThunk(
  "calendarApp/events/updateEvent",
  async (event, { dispatch }) => {
    const accessToken = window.localStorage.getItem("jwt_access_token");
    const requestBody = {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
        body: JSON.stringify(event),
      },
    };
    var response = await fetch(
      `${setupKey}appointments/${event.id}`,
      requestBody
    ).then((data) => data.json());
    const data = response.data;

    return data;
  }
);

export const removeEvent = createAsyncThunk(
  "calendarApp/events/removeEvent",
  async (eventId, { dispatch }) => {
    const accessToken = window.localStorage.getItem("jwt_access_token");
    const requestBody = {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    };
    var response = await fetch(
      `${setupKey}appointments/${event.id}`,
      requestBody
    ).then((data) => data.json());
    const data = response.data;

    return data;
  }
);

const eventsAdapter = createEntityAdapter({});

export const {
  selectAll: selectEvents,
  selectIds: selectEventIds,
  selectById: selectEventById,
} = eventsAdapter.getSelectors((state) => state.calendarApp.events);

const eventsSlice = createSlice({
  name: "calendarApp/events",
  initialState: eventsAdapter.getInitialState({
    eventDialog: {
      type: "new",
      props: {
        open: false,
        anchorPosition: { top: 200, left: 400 },
      },
      data: null,
    },
  }),
  reducers: {
    openNewEventDialog: {
      prepare: (selectInfo) => {
        const { start, end, jsEvent } = selectInfo;
        const payload = {
          type: "new",
          props: {
            open: true,
            anchorPosition: { top: jsEvent.pageY, left: jsEvent.pageX },
          },
          data: {
            start: formatISO(new Date(start)),
            end: formatISO(new Date(end)),
          },
        };
        return { payload };
      },
      reducer: (state, action) => {
        state.eventDialog = action.payload;
      },
    },
    openEditEventDialog: {
      prepare: (clickInfo) => {
        const { jsEvent, event } = clickInfo;
        const { id, title, allDay, start, end, extendedProps } = event;

        const payload = {
          type: "edit",
          props: {
            open: true,
            anchorPosition: { top: jsEvent.pageY, left: jsEvent.pageX },
          },
          data: {
            id,
            title,
            allDay,
            extendedProps,
            start: formatISO(new Date(start)),
            end: formatISO(new Date(end)),
          },
        };
        return { payload };
      },
      reducer: (state, action) => {
        state.eventDialog = action.payload;
      },
    },
    closeNewEventDialog: (state, action) => {
      state.eventDialog = {
        type: "new",
        props: {
          open: false,
          anchorPosition: { top: 200, left: 400 },
        },
        data: null,
      };
    },
    closeEditEventDialog: (state, action) => {
      state.eventDialog = {
        type: "edit",
        props: {
          open: false,
          anchorPosition: { top: 200, left: 400 },
        },
        data: null,
      };
    },
  },
  extraReducers: {
    [getEvents.fulfilled]: eventsAdapter.setAll,
    [addEvent.fulfilled]: eventsAdapter.addOne,
    [updateEvent.fulfilled]: eventsAdapter.upsertOne,
    [removeEvent.fulfilled]: eventsAdapter.removeOne,
  },
});

export const {
  openNewEventDialog,
  closeNewEventDialog,
  openEditEventDialog,
  closeEditEventDialog,
} = eventsSlice.actions;

export const selectFilteredEvents = createSelector(
  [selectSelectedLabels, selectEvents],

  (selectedLabels, events) => {
    console.log("vv", selectedLabels);
    console.log("Event", events);
    return events?.filter((item) =>
      selectedLabels?.includes(item?.extendedProps?.label)
    );
  }
);

export const selectEventDialog = ({ calendarApp }) =>
  calendarApp.events.eventDialog;

export default eventsSlice.reducer;
