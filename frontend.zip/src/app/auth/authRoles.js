/**
 * Authorization Roles
 */
const authRoles = {
  admin: ["SuperAdmin"],
  headStaff: ["admin"],
  staff: ["manager", "provider", "user"],
  onlyGuest: [],
};

export default authRoles;
